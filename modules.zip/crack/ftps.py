import os
os.system("clear")
os.system("figlet FTP Brute Force | lolcat")
x = input("Enter The Target IP: ")
y = input("Enter The Target User: ")
z = input("Enter The Wordlist: ")

h = "python2 modules/crack/ftp.py " + x + " " + y + " " + z
os.system(h)
