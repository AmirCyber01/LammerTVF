import os
os.system("clear")
print'''

                     _    _
  ___ _ __ __ _  ___| | _(_)_ __   __ _
 / __| '__/ _` |/ __| |/ / | '_ \ / _` |
| (__| | | (_| | (__|   <| | | | | (_| |
 \___|_|  \__,_|\___|_|\_\_|_| |_|\__, |
                                  |___/

==========================================
code by mehdi652 & mohamadg80

https://jailbreakandroot.tk
==========================================

        {1} gmail cracker
        ==========================
        {2} instagram user Lecher
        ==========================
        {3} router admin panel bruteforce
        ==========================
        {4} ip changer (proxy)
        ==========================
        {5} ftp brute force

        {99} back




'''

x = input("jailbreakandroot=>  ")

if x == 1:
   os.system("python2 modules/crack/gmail.py")
if x == 99:
   os.system("python2 jrf.py")
if x == 2:
   os.system("python3 modules/crack/lecher.py")
if x == 3:
   os.system("python2 modules/crack/ruter.py")
if x == 4:
   os.system("python3 modules/crack/proxy.py")
if x == 5:
   os.system("python3 modules/crack/ftps.py")
