import requests, time




list1 = input("\nEnter the proxy list: ")
times = int(input("Enter the time sleep: \n"))
file = open(list1, "r")
proxy = []
for i in file:
    time.sleep(times)
    proxies = {"https":"socks5://%s" % i.replace("\n","")}
    url = "http://www.showmemyip.com/"
    headers={'User-agent' : 'Mozilla/5.0'}
    request = requests.get(url,proxies=proxies,headers=headers)
    html = request.content
    print(html)
