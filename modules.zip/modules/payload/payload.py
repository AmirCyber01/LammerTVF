#payload-jilrot
#https://jailbreakandroot.tk
#mohamadg80 & mehdi652

import os
os.system("clear")

print'''
\033[1;31m
       ,#############################,
       ################################
      ##################################
      ###                            ###
      ###   $$$$$            $$$$$   ###
      ###   $$$$$            $$$$$   ###
      ###    ```      """     ```    ###
       ###           """""          ###
       ###           """""          ###
        ###                        ###
         ###                      ###
          ###                    ###
             ====================
             =||||||||||||||||||=
             =------------------=
             =||||||||||||||||||=
             ====================
\033[1;m   \033[1;32m
               

         code by mehdi652 & mohamadg80
         https://jailbreakandroot.tk
\033[1;m
'''

print ("+ metasploit installed?")
print ("                       ")
print ("                       ")
print ("                       ")


print ("[1] android/meterpreter/reverse_tcp")
print ("[2] windows/meterpreter/reverse_tcp")
print ("[3] php/meterpreter/reverse_tcp")
print ("[4] java/meterpreter/reverse_tcp")
print ("[5] python/meterpreter/reverse_tcp")
print ("[99] exit")
print'''




'''

x = input("payload-jilrot~>  ")


if x == 1:
   os.system("python3 modules/payload/p1.py")
if x == 2:
   os.system("python3 modules/payload/p2.py")
if x == 3:
   os.system("python3 modules/payload/p3.py")
if x == 4:
   os.system("python3 modules/payload/p4.py")
if x == 5:
   os.system("python3 modules/payload/p5.py")
if x == 99:
   os.system("python2 jrf.py")
