#nmap

import os

os.system("clear")
os.system("figlet Nmap | lolcat")


print'''
\033[1;91m
                Create By AmirCyber01
====================================================
[+]  Team       : LammerTV                       
[+]  Programmer : AmirCyber01 ;)         
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================
\033[1;m
\033[1;92m    
        [1] Port Scan
        =======================
        [2] Simple List  Scan
        =======================
        [3] Host Up Scan
        =======================
        [4] Service Scan
        =======================
        [5] Anonymous FTP Scan
        =======================
        [99] Back
\033[1;m


'''

x = input("LammerTV=>  ")


if x == 1:
   os.system("python3 modules/nmap/nmap1.py")
if x == 2:
   os.system("python3 modules/nmap/nmap2.py")
if x == 3:
   os.system("python3 modules/nmap/nmap3.py")
if x == 4:
   os.system("python3 modules/nmap/nmap4.py")
if x == 5:
   os.system("python3 modules/nmap/nmap5.py")
if x == 99:
   os.system("python2 LammerTV.py")
