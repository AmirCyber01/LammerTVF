import os

x = input("Enter The IP:  ")

x1 = "nmap -sC " + x + " -p 21"
os.system(x1)
