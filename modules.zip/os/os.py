import os
os.system("clear")
os.system("figlet Linux OS | lolcat")

print'''

\033[1;36m
                Create By AmirCyber01
==================================================== 
[+]  Team       : LammerTV                       
[+]  Programmer : AmirCyber01 ;)         
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================      
\033[1;m
'''
print'''
\033[1;93m

  [1] Kali
  ========================
  [2] Ubuntu
  ========================
  [3] Debian
  ========================
  [4] Fedora
  ========================
  [5] Arch
  ========================
  [6] Black Arch
  ========================
  [7] Parrot Security OS
  ========================
  [99] Back
'''

x = input("LammerTV=>  ")

if x == 1:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Kali/kali.sh && bash kali.sh")
if x == 2:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Ubuntu/ubuntu.sh && bash ubuntu.sh")
if x == 3:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Debian/debian.sh && bash debian.sh")
if x == 4:
   os.system("cd $HOME")
   os.system("pkg install wget proot tar -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Fedora/fedora.sh && bash fedora.sh")
if x == 5:
   os.system("cd $HOME")
   os.system("pkg install wget proot tar -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Arch/armhf/arch.sh && bash arch.sh")
if x == 6:
   os.system("cd $HOME")
   os.system("pacman-key --init && pacman-key --populate archlinuxarm && pacman -Sy --noconfirm curl && curl -O https://blackarch.org/strap.sh && chmod +x strap.sh && ./strap.sh")
if x == 7:
   os.system("cd $HOME")
   os.system("pkg install wget proot -y && wget https://raw.githubusercontent.com/EXALAB/AnLinux-Resources/master/Scripts/Installer/Parrot/parrot.sh && bash parrot.sh")
if x == 99:
   os.system("python2 LammerTV.py")
