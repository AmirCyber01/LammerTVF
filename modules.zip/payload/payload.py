#payload

import os
os.system("clear")
os.system("figlet PayLoad | lolcat")
print'''
\033[1;31m
       ,#############################,
       ################################
      ##################################
      ###                            ###
      ###   $$$$$            $$$$$   ###
      ###   $$$$$            $$$$$   ###
      ###    ```      """     ```    ###
       ###           """""          ###
       ###           """""          ###
        ###                        ###
         ###                      ###
          ###                    ###
             ====================
             =||||||||||||||||||=
             =------------------=
             =||||||||||||||||||=
             ====================
\033[1;m   \033[1;32m
               
                Create By AmirCyber01
==================================================== 
[+]  Team       : LammerTV                       
[+]  Programmer : AmirCyber01 ;)         
[+]  Github     : https://github.com/AmirCyber01                                                             
[+]  Instagram  : https://instagram.com/Amir__s.p.g
[+]  Telegram   : https://t.me/Amir_cybery
====================================================      
\033[1;m
'''

print ("+ metasploit installed?")
print ("                       ")
print ("                       ")
print ("                       ")


print ("[1] android/meterpreter/reverse_tcp")
print ("[2] windows/meterpreter/reverse_tcp")
print ("[3] php/meterpreter/reverse_tcp")
print ("[4] java/meterpreter/reverse_tcp")
print ("[5] python/meterpreter/reverse_tcp")
print ("[99] exit")
print'''



'''

x = input("LammerTV~>  ")


if x == 1:
   os.system("python3 modules/payload/p1.py")
if x == 2:
   os.system("python3 modules/payload/p2.py")
if x == 3:
   os.system("python3 modules/payload/p3.py")
if x == 4:
   os.system("python3 modules/payload/p4.py")
if x == 5:
   os.system("python3 modules/payload/p5.py")
if x == 99:
   os.system("python2 LammerTV.py")
